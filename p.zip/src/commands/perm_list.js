
const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { canManageSettings } = require("../utils/perms");
const { pool } = require("../db/pool");

function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("perm_list")
    .setDescription("List all commands with custom permission rules (Manage Server / Owner).")
    .addIntegerOption(o =>
      o.setName("page")
        .setDescription("Page number")
        .setRequired(false)
    ),
  async execute(interaction) {
    if (!interaction.guildId) return interaction.reply({ content: "Server only.", ephemeral: true });
    if (!canManageSettings(interaction)) return interaction.reply({ content: "Requires **Manage Server** (or Owner).", ephemeral: true });

    const page = Math.max(1, interaction.options.getInteger("page") || 1);

    const { rows } = await pool.query(
      `SELECT command_name, allowed_role_ids, allow_manage_guild
       FROM command_permissions
       WHERE guild_id=$1
       ORDER BY command_name ASC`,
      [interaction.guildId]
    );

    if (!rows.length) {
      const embed = new EmbedBuilder()
        .setTitle("Permissions")
        .setDescription("No custom permission rules set in this server.");
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const lines = rows.map(r => {
      const roleIds = (r.allowed_role_ids || []).map(String).filter(Boolean);
      const roles = roleIds.length ? roleIds.map(id => `<@&${id}>`).join(", ") : "none";
      const bypass = r.allow_manage_guild ? "ON" : "OFF";
      return `**/${r.command_name}** — ${roles}  |  bypass: **${bypass}**`;
    });

    const pages = chunk(lines, 12);
    const maxPage = pages.length;
    const p = Math.min(page, maxPage);

    const embed = new EmbedBuilder()
      .setTitle("Permissions")
      .setDescription(pages[p - 1].join("\n"))
      .setFooter({ text: `Page ${p}/${maxPage}` });

    return interaction.reply({
      embeds: [embed],
      ephemeral: true,
      allowedMentions: { parse: [] },
    });
  }
};
