
const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { canManageSettings } = require("../utils/perms");
const { measureDbLatency } = require("../utils/dbHelpers");
const { pool } = require("../db/pool");

async function tableHasRows(sql, params) {
  const { rows } = await pool.query(sql, params);
  return rows?.[0]?.c ? Number(rows[0].c) : 0;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("diag")
    .setDescription("Run quick diagnostics (Manage Server / Owner)."),
  async execute(interaction, client) {
    if (!interaction.guildId) return interaction.reply({ content: "Server only.", ephemeral: true });
    if (!canManageSettings(interaction)) return interaction.reply({ content: "Requires **Manage Server** (or Owner).", ephemeral: true });

    await interaction.deferReply({ ephemeral: true }).catch(() => {});

    // DB latency
    let db = { ok: true, latency: "n/a", error: null };
    try {
      const ms = await measureDbLatency();
      db.latency = `${ms}ms`;
    } catch (e) {
      db.ok = false;
      db.error = e?.message || String(e);
    }

    // Basic config checks
    const missing = [];
    for (const k of ["BOT_TOKEN", "APP_ID", "OWNER_ID", "DATABASE_URL"]) {
      if (!process.env[k]) missing.push(k);
    }

    // Channel settings presence (best-effort, won't fail diag if tables differ)
    const guildId = interaction.guildId;
    const checks = [];

    async function checkSetting(name, sql) {
      try {
        const count = await tableHasRows(sql, [guildId]);
        checks.push({ name, value: count ? "set" : "not set" });
      } catch {
        checks.push({ name, value: "unknown" });
      }
    }

    await checkSetting("Deploy channel", "SELECT COUNT(*)::int AS c FROM deploy_channel_settings WHERE guild_id=$1 AND enabled=TRUE");
    await checkSetting("Roblox alerts", "SELECT COUNT(*)::int AS c FROM roblox_alert_settings WHERE guild_id=$1 AND enabled=TRUE");
    await checkSetting("Error alerts", "SELECT COUNT(*)::int AS c FROM error_alert_settings WHERE guild_id=$1 AND enabled=TRUE");
    await checkSetting("Backup channel", "SELECT COUNT(*)::int AS c FROM backup_channel_settings WHERE guild_id=$1 AND enabled=TRUE");

    // Bot permissions in this guild (rough)
    let permsOk = "unknown";
    try {
      const me = interaction.guild.members.me;
      if (me) {
        const need = ["ViewChannel", "SendMessages", "EmbedLinks", "ManageChannels"];
        const missingPerms = need.filter(p => !me.permissions.has(p));
        permsOk = missingPerms.length ? `missing: ${missingPerms.join(", ")}` : "ok";
      }
    } catch {}

    const embed = new EmbedBuilder()
      .setTitle("Diagnostics")
      .addFields(
        { name: "DB", value: db.ok ? `ok (${db.latency})` : `fail (${db.error?.slice(0, 120)})`, inline: true },
        { name: "Commands loaded", value: String(client?.commands?.size || 0), inline: true },
        { name: "Bot permissions", value: permsOk, inline: false },
        { name: "Missing env", value: missing.length ? missing.join(", ") : "none", inline: false },
        { name: "Config", value: checks.map(x => `**${x.name}:** ${x.value}`).join("\n"), inline: false }
      );

    return interaction.editReply({ embeds: [embed] }).catch(() => {});
  },
};
